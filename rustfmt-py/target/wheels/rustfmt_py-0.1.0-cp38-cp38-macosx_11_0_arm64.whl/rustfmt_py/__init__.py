from .rustfmt_py import *

__doc__ = rustfmt_py.__doc__
